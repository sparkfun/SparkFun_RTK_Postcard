Version: LG290P03AANR01A04S_BETA0212

Default Configuration:
(1) The default satellite constellation configuration is GPS L1/L2/L5 + GLONASS L1/L2 + Galileo E1/E5a/E5b/E6 + BDS B1I/B1C/B2a/B2b/B2I/B3I + QZSS L1/L2/L5 + NavIC L5.
(2) The default UART baud rate is 460800 bps.

Change Point:
(1) Changed <RMS_D>, <MajorD>, <MinorD>, <Orient>, <LatD>, <LonD> and <AltD> field values in the GST message from 1 decimal place to 3 decimal places.

版本：LG290P03AANR01A04S_BETA0212

默认配置：
（1）默认星系配置：GPS L1/L2/L5 + GLONASS L1/L2 + Galileo E1/E5a/E5b/E6 + BDS B1I/B1C/B2a/B2b/B2I/B3I + QZSS L1/L2/L5 + NavIC L5。
（2）默认UART接口波特率：460800 bps。

修改点：
（1）将GST语句中的<RMS_D>、<MajorD>,<MinorD>、<Orient>、<LatD>、<LonD>和 <AltD>字段值由1位小数改为3位小数。



 
