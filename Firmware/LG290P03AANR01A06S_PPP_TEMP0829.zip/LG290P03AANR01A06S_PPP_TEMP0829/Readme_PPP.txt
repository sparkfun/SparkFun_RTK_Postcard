Note:
(1) The current version of PPP can only support 1 Hz and 10 Hz solution, default 10 Hz.
(2) Currently supports the configuration of two PPP modes: PPP-B2b and HAS. The current <Mode> field 0x00 = Disable (default), 0x01 = B2b PPP, 0x02 = E6 HAS is effective, and other fields and modes are temporarily ineffective.
(3) The current version of Datum only supports the 2 = PPP original. 
(4) The current PPP float solution is still marked with 5 in GGA. The differential age outputs the age of the PPP correction number clock difference product. In addition, to facilitate the distinction from RTK, the stationID of the PPP result based on the B2b correction number is 9001, and the stationID of the PPP result based on the HAS correction number is 9002.

Description related to $PQTMCFGPPP command.
Type:Set/Get
Synopsis:
     //Set:
     PQTMCFGPPP,W,<Mode>[,<Datum>,<Timeout>,<HorStd>,<VerStd>]*<Checksum><CR><LF>
     //Get:
     $PQTMCFGPPP,R*<Checksum><CR><LF>
Parameter:
     <Mode>: PPP mode.
	0x00 = Disable    
	0x01 = B2b PPP    
	0x02 = E6 HAS    
	0x04 = L6 MADOCA   
	0x08 = SSR-RX   
	0xFF = Auto
     <Datum>: Reference coordinate system. 
	1 = WGS84   
	2 = PPP original
     <Timeout>: PPP timeout. Unit：second. Range: [90,180]. Default: 120.
     <HorStd>：Horizontal convergence accuracy threshold. Unit：meter. Range: [0,5]. Default: 0.10. 
     <VerStd>：Vertical convergence accuracy threshold. Unit：meter. Range: [0,5]. Default: 0.15.
Result：
     If successful, the module returns:
     //Set:
     $PQTMCFGPPP,OK*<Checksum><CR><LF>
     //Get:
     $PQTMCFGPPP,OK,<Mode>,<Datum>,<Timeout>,<HorStd>,<VerStd>*<Checksum><CR><LF>
     If failed, the module returns:
     $PQTMCFGPPP,ERROR,<ErrCode>*<Checksum><CR><LF>
Example:
     //Set:
     $PQTMCFGPPP,W,1,2,120,0.10,0.15*68
     $PQTMCFGPPP,OK*22
     //Get:
     $PQTMCFGPPP,R*74
     $PQTMCFGPPP,OK,01,2,120,0.10,0.15*0B

注意：
（1）当前版本PPP只能支持1 Hz和10 Hz解算，默认10 Hz。
（2）当前支持PPP-B2b和HAS两种PPP模式的配置，当前Mode字段的0x00 = Disable（默认），0x01 = B2b PPP，0x02 = E6 HAS生效，其他字段和模式暂时都无法生效。
（3）当前版本Datum仅支持2 = PPP本身坐标系。
（4）当前PPP浮点解在GGA中仍然用5来标识，差分龄期输出PPP改正数钟差产品的龄期，另外，为便于跟RTK做区分，基于B2b改正数的PPP结果的stationID是9001，基于HAS改正数的PPP结果的stationID是9002。

$PQTMCFGPPP指令相关信息
类型：设置/查询
格式：
     //设置：
     PQTMCFGPPP,W,<Mode>[,<Datum>,<Timeout>,<HorStd>,<VerStd>]*<Checksum><CR><LF>
     //查询：
     $PQTMCFGPPP,R*<Checksum><CR><LF>
参数：
     <Mode>：PPP模式。
	0x00 = 禁用    
	0x01 = B2b PPP    
	0x02 = E6 HAS    
	0x04 = L6 MADOCA   
	0x08 = SSR-RX   
	0xFF = 自动
     <Datum>：参考坐标系。
	1 = WGS84   
	2 = PPP本身坐标系
     <Timeout>：PPP差分龄期。单位：秒。范围：[90,180]。默认值：120。
     <HorStd>：水平收敛精度阈值。单位：米。范围：[0,5]。默认值：0.10 。
     <VerStd>：垂直收敛精度阈值。单位：米。范围：[0,5]。默认值：0.15。
结果：
     如果成功，模块返回：
     //设置：
     $PQTMCFGPPP,OK*<Checksum><CR><LF>
     //查询：
     $PQTMCFGPPP,OK,<Mode>,<Datum>,<Timeout>,<HorStd>,<VerStd>*<Checksum><CR><LF>
     如果失败，模块返回：
     $PQTMCFGPPP,ERROR,<ErrCode>*<Checksum><CR><LF>
示例：
     //设置：
     $PQTMCFGPPP,W,1,2,120,0.10,0.15*68
     $PQTMCFGPPP,OK*22
     //查询：
     $PQTMCFGPPP,R*74
     $PQTMCFGPPP,OK,01,2,120,0.10,0.15*0B
