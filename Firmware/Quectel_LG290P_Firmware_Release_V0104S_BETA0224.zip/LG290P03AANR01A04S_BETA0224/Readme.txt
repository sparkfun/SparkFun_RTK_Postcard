Version: LG290P03AANR01A04S_BETA0224

Default Configuration:
(1) The default satellite constellation configuration is GPS L1/L2/L5 + GLONASS L1/L2 + Galileo E1/E5a/E5b/E6 + BDS B1I/B1C/B2a/B2b/B2I/B3I + QZSS L1/L2/L5 + NavIC L5.
(2) The default UART baud rate is 460800 bps.

Change Point:
(1) Fixed the problem of incorrect <Sep> field in GGA message.

版本：LG290P03AANR01A04S_BETA0224

默认配置：
（1）默认星系配置：GPS L1/L2/L5 + GLONASS L1/L2 + Galileo E1/E5a/E5b/E6 + BDS B1I/B1C/B2a/B2b/B2I/B3I + QZSS L1/L2/L5 + NavIC L5。
（2）默认UART接口波特率：460800 bps。

修改点：
（1）修复了GGA语句中的<Sep>字段错误的问题。